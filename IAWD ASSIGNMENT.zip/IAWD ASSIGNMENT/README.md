# Books4MU-Book-Store-Website-
Books4MU is an Online book store Project completed during TCR Innovation Internship using HTML CSS and JavaScript.
# Abstrat
Abstract - BOOKS4MU is an Online Book Store for Mumbai University Students pursuing their Computer Engineering ,where they can purchase books online. Through this website the
students can search for a book, later can add the selected book to the shopping cart and finally purchase it.
# Screenshot
## Home Page :
![image](https://github.com/KordePriyanka/Books4MU-Book-Store-Website-/assets/98102061/3af4f982-8c75-4cdd-bd34-9309657b558f)
## Login Page:
![image](https://github.com/KordePriyanka/Books4MU-Book-Store-Website-/assets/98102061/47c99d08-0e92-4299-aaa0-341f587980d6)
## Cart Page:
![image](https://github.com/KordePriyanka/Books4MU-Book-Store-Website-/assets/98102061/b31730e5-3b05-471e-8058-c5c77765fa8f)
## Documentation
(https://drive.google.com/file/d/1sUaCLNa-rYuv22EB1Hf4R5jxRXN5uAkF/view?usp=sharing)https://drive.google.com/file/d/1sUaCLNa-rYuv22EB1Hf4R5jxRXN5uAkF/view?usp=sharing)
